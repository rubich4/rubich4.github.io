#pragma once

#include <vector>
#include <unordered_map>
#include <memory>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtx/quaternion.hpp>
#include "ope/ECSManager.hpp"
#include "ope/Mesh.hpp"
#include "ope/Transform.hpp"

// Estructura para representar una Bounding Box Alineada con los Ejes (AABB)
struct AABB {
    glm::vec3 min;
    glm::vec3 max;

    AABB() : min(glm::vec3(0.0f)), max(glm::vec3(0.0f)) {}
    AABB(const glm::vec3& min, const glm::vec3& max) : min(min), max(max) {}

    // Verifica si esta AABB se interseca con otra
    bool intersects(const AABB& other) const;

    // Calcula el centro de la AABB
    glm::vec3 getCenter() const;

    // Calcula las dimensiones de la AABB
    glm::vec3 getDimensions() const;

    // Transforma la AABB según una matriz de transformación
    AABB transform(const glm::mat4& transform) const;
};

// Estructura para representar un triángulo en 3D
struct Triangle {
    glm::vec3 v0, v1, v2;

    Triangle() {}
    Triangle(const glm::vec3& v0, const glm::vec3& v1, const glm::vec3& v2) : v0(v0), v1(v1), v2(v2) {}

    // Calcula la normal del triángulo
    glm::vec3 getNormal() const;

    // Calcula el AABB del triángulo
    AABB getAABB() const;
};

// Estructura para representar un nodo de Octree
class OctreeNode {
public:
    OctreeNode(const AABB& bounds, int depth = 0);
    ~OctreeNode();

    // Inserta una entidad con su AABB en el Octree
    void insert(Entity entity, const AABB& aabb);

    // Consulta todas las entidades que potencialmente podrían colisionar con la entidad dada
    std::vector<Entity> queryPotentialCollisions(Entity entity, const AABB& aabb);

    // Limpia el Octree (elimina todas las entidades)
    void clear();

private:
    AABB bounds;               // Límites de este nodo
    int depth;                 // Profundidad del nodo en el árbol
    static const int MAX_DEPTH = 8;  // Profundidad máxima del Octree
    static const int MAX_ENTITIES_PER_NODE = 16;  // Entidades máximas por nodo antes de subdividir

    std::vector<std::pair<Entity, AABB>> entities;   // Entidades en este nodo
    std::vector<std::unique_ptr<OctreeNode>> children;  // Nodos hijos (8 o ninguno)

    // Divide este nodo en 8 nodos hijos
    void subdivide();

    // Determina en qué nodo hijo debería ir una AABB
    int getChildIndexForAABB(const AABB& aabb) const;
};

// Componente de física para entidades
struct PhysicsComponent {
    // Propiedades de traslación
    glm::vec3 velocity;            // Velocidad actual
    glm::vec3 prevPosition;        // Posición anterior (para integración de Verlet)
    glm::vec3 acceleration;        // Aceleración actual

    // Propiedades físicas
    float mass;                    // Masa del objeto
    float inverseMass;             // Inversa de la masa (para cálculos de colisión)
    float restitution;             // Coeficiente de restitución (elasticidad)
    float friction;                // Coeficiente de fricción
    bool isStatic;                 // Si es verdadero, el objeto no se mueve pero colisiona
    bool useGravity;               // Si es verdadero, se aplica gravedad al objeto

    // Propiedades de colisión
    AABB boundingBox;              // Caja delimitadora para detección de colisiones
    std::vector<Triangle> triangles; // Triángulos para colisiones precisas

    // Propiedades de rotación
    glm::vec3 angularVelocity;     // Velocidad angular (radianes/segundo)
    glm::vec3 torque;              // Torque aplicado al objeto
    glm::quat orientation;         // Orientación actual (quaternion)
    glm::quat prevOrientation;     // Orientación anterior (para integración de Verlet)
    glm::mat3 inertiaTensor;       // Tensor de inercia en espacio de modelo
    glm::mat3 inverseInertiaTensor; // Inverso del tensor de inercia

    PhysicsComponent()
        : velocity(0.0f),
        prevPosition(0.0f),
        acceleration(0.0f),
        mass(1.0f),
        inverseMass(1.0f),
        restitution(0.5f),
        friction(0.5f),
        isStatic(false),
        useGravity(true),
        angularVelocity(0.0f),
        torque(0.0f),
        orientation(1.0f, 0.0f, 0.0f, 0.0f), // Quaternion de identidad
        prevOrientation(1.0f, 0.0f, 0.0f, 0.0f)
    {
        // Inicializar tensor de inercia por defecto (cubo de 1x1x1)
        float diagValue = (mass / 6.0f);
        inertiaTensor = glm::mat3(
            diagValue, 0.0f, 0.0f,
            0.0f, diagValue, 0.0f,
            0.0f, 0.0f, diagValue
        );

        // Calcular inverso
        inverseInertiaTensor = glm::inverse(inertiaTensor);
    }
};

// Sistema de física para manejar la simulación
class PhysicsSystem {
public:
    PhysicsSystem();
    ~PhysicsSystem();

    // Inicializa el sistema de física
    void initialize();

    // Actualiza la simulación de física
    void update(EntityManager& em, ComponentManager& cm, float deltaTime);

    // Añade una entidad al sistema de física
    void addEntityToPhysics(Entity entity, ComponentManager& cm, bool isStatic = false);

    // Remueve una entidad del sistema de física
    void removeEntityFromPhysics(Entity entity);

    // Configura la gravedad del mundo
    void setGravity(const glm::vec3& gravity);

    // Obtiene la gravedad actual
    glm::vec3 getGravity() const;

private:
    OctreeNode octree;        // Octree para detección de colisiones
    glm::vec3 gravity;        // Vector de gravedad para el mundo
    float fixedTimeStep;      // Paso de tiempo fijo para la simulación

    // Actualiza las AABBs de todas las entidades basado en sus transformaciones
    void updateAABBs(EntityManager& em, ComponentManager& cm);

    // Detecta colisiones entre entidades
    void detectCollisions(EntityManager& em, ComponentManager& cm);

    // Resuelve las colisiones detectadas
    void resolveCollisions(EntityManager& em, ComponentManager& cm);

    // Aplica la integración de Verlet a una entidad
    void applyVerletIntegration(Entity entity, PhysicsComponent& physics, TransformComponent& transform, float deltaTime);

    // Crea una AABB a partir de los vértices de una malla
    AABB createAABBFromMesh(const MeshComponent& mesh, const TransformComponent& transform);

    // Detecta colisión entre dos triángulos
    bool triangleTriangleCollision(const Triangle& t1, const Triangle& t2, glm::vec3& collisionPoint, glm::vec3& collisionNormal, float& penetrationDepth);

    // Detecta colisión entre dos AABBs
    bool aabbCollision(const AABB& box1, const AABB& box2);

    // Extrae los triángulos de una malla
    std::vector<Triangle> extractTrianglesFromMesh(const MeshComponent& mesh, const TransformComponent& transform);

    // Calcula la profundidad de penetración entre dos AABBs
    float calculatePenetrationDepth(const AABB& box1, const AABB& box2);

    // Nuevos métodos para rotación física

    // Calcula el tensor de inercia basado en la geometría de la malla
    void calculateInertiaTensor(PhysicsComponent& physics, const MeshComponent& mesh);

    // Aplica un alineamiento con el suelo para objetos casi en reposo
    void alignToGround(PhysicsComponent& physics, TransformComponent& transform);

    // Aplica un impulso rotacional en un punto específico del objeto
    void applyImpulseAtPoint(PhysicsComponent& physics, const glm::vec3& impulse, const glm::vec3& point, const glm::vec3& centerOfMass);

    // Calcula la matriz del tensor de inercia en espacio mundial
    glm::mat3 calculateWorldInertiaTensor(const PhysicsComponent& physics);
};