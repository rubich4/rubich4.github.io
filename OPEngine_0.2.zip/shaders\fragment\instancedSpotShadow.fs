#version 330 core

void main() {
    // Este shader es simple, OpenGL automáticamente escribe
    // la profundidad en el depth buffer
    // No necesitamos hacer nada específicamente
}