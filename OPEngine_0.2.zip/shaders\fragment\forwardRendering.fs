#version 420 core

struct Light {
    int type_light;  // 0: Point Light, 1: Directional Light, 2: Spot Light
    vec3 position;
    vec3 direction;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float constant;
    float linear;
    float quadratic;
    float cutoff;
    float outerCutoff;
    float strength;
    float bias;
    float maxDistance;
};

uniform Light light;
uniform vec3 viewPos;
layout(binding = 0) uniform sampler2D texture_diffuse1;
layout(binding = 2) uniform samplerCube shadowCubeMap; // Para luces puntuales
layout(binding = 3) uniform sampler2D shadowMap;      // Para luces direccionales
layout(binding = 4) uniform sampler2D spotShadowMap;  // Para luces focales
uniform float farPlane;
uniform int lightPass;            
uniform vec3 globalAmbient;       // Iluminaci�n ambiental global
uniform vec4 u_color;

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;
in vec4 FragPosLightSpace;

out vec4 FragColor;


float ShadowCalculation(vec4 fragPosLightSpace, sampler2D shadowMap) {
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;
    
    if (projCoords.z > 1.0)
        return 0.0;
        
    float closestDepth = texture(shadowMap, projCoords.xy).r;
    float currentDepth = projCoords.z;
    
    float adjustedBias = light.bias * (1.0 - dot(Normal, normalize(-light.direction)));
    
    // PCF (Percentage Closer Filtering)
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(shadowMap, 0);
    for(int x = -1; x <= 1; ++x) {
        for(int y = -1; y <= 1; ++y) {
            float pcfDepth = texture(shadowMap, projCoords.xy + vec2(x, y) * texelSize).r; 
            shadow += currentDepth - adjustedBias > pcfDepth ? 1.0 : 0.0;        
        }    
    }
    shadow /= 9.0;
    
    return shadow;
}

float PointShadowCalculation(vec3 fragPos) {
    vec3 fragToLight = fragPos - light.position;
    float currentDepth = length(fragToLight) / farPlane;
    
    vec3 sampleDir = normalize(fragToLight);
    float closestDepth = texture(shadowCubeMap, sampleDir).r;
    
    float bias = light.bias;
    float shadow = currentDepth - bias > closestDepth ? 1.0 : 0.0;

    if(currentDepth >= 0.99) {
        shadow = 0.0;
    }
    
    return shadow;
}

float SpotShadowCalculation(vec4 fragPosLightSpace) {
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;

    if (projCoords.z > 1.0 || projCoords.x < 0.0 || projCoords.x > 1.0 || 
        projCoords.y < 0.0 || projCoords.y > 1.0)
        return 0.0;
        
    float closestDepth = texture(spotShadowMap, projCoords.xy).r;
    float currentDepth = projCoords.z;
    
    // PCF simplificado
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(spotShadowMap, 0);
    for(int x = -1; x <= 1; ++x) {
        for(int y = -1; y <= 1; ++y) {
            float pcfDepth = texture(spotShadowMap, projCoords.xy + vec2(x, y) * texelSize).r; 
            shadow += currentDepth - light.bias > pcfDepth ? 1.0 : 0.0;        
        }    
    }
    shadow /= 9.0;

    return shadow; 
}

void main() {
    vec4 texColor = texture(texture_diffuse1, TexCoords);

    texColor *= u_color;
    
    // Si es el pase de ambiente (lightPass = 0), solo usar luz ambiental global
    if (lightPass == 0) {
        FragColor = vec4(globalAmbient * texColor.rgb, texColor.a);
        return;
    }
    
    // Para los pases de luz individuales
    vec3 norm = normalize(Normal);
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 lightDir;
    float attenuation = 1.0;
    float shadow = 0.0;
    
    if (light.type_light == 0) { // Point Light
        lightDir = normalize(light.position - FragPos);
        float distance = length(light.position - FragPos);
        attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
        
        shadow = PointShadowCalculation(FragPos);
    } 
    else if (light.type_light == 1) { // Directional Light
        lightDir = normalize(-light.direction);
        attenuation = 1.0;
        
        shadow = ShadowCalculation(FragPosLightSpace, shadowMap);
    } 
    else if (light.type_light == 2) { // Spot Light
        lightDir = normalize(light.position - FragPos);
        float theta = dot(lightDir, normalize(-light.direction));
        float epsilon = light.cutoff - light.outerCutoff;
        float intensity = clamp((theta - light.outerCutoff) / epsilon, 0.0, 1.0);
        float distance = length(light.position - FragPos);
        attenuation = (1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance))) * intensity;
        
        shadow = SpotShadowCalculation(FragPosLightSpace);
    }

    vec3 ambient = light.ambient * attenuation * light.strength;
    
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = light.diffuse * diff * attenuation * light.strength;
    
    vec3 reflectDir = reflect(-lightDir, norm);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32.0);
    vec3 specular = light.specular * spec * attenuation * light.strength;

    vec3 lighting = ambient + (diffuse + specular) * (1.0 - shadow);
    vec3 finalColor = lighting * texColor.rgb;
    
    FragColor = vec4(finalColor, texColor.a);
}