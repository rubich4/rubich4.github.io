#ifndef GPU_INSTANCING_MESH_HPP
#define GPU_INSTANCING_MESH_HPP

#include <vector>
#include <memory>
#include <glm/glm.hpp>

class EntityManager;
class ComponentManager;

using Entity = std::uint32_t;

struct InstanceData {
    glm::mat4 modelMatrix;   
    glm::vec3 color;

    InstanceData(const glm::mat4& modelMatrix, const glm::vec3& color = glm::vec3(1.0f))
        : modelMatrix(modelMatrix), color(color) {}
};

class InstancedMeshComponent {
public:
    MeshComponent mesh;                     // Malla base que se instanciar�
    std::vector<InstanceData> instances;    // Datos de cada instancia
    unsigned int instanceVBO;               // Buffer de instancias
    unsigned int maxInstances;

     InstancedMeshComponent(MeshData data, unsigned int maxInstances = 1000);
    ~InstancedMeshComponent();

    void setupInstanceBuffer();

    void addInstance(const glm::mat4& modelMatrix, const glm::vec3& color = glm::vec3(1.0f));

    void updateInstanceBuffer();

    void clearInstances();

    void placeInstancesOnTerrain(EntityManager& em, ComponentManager& cm, Entity terrain,
                                glm::vec3 scale, glm::vec2 heightRange, int totalInstances);

private:
    float getRandomFloat(float min, float max);
    std::vector<glm::vec3> selectRandomPositions(const std::vector<glm::vec3>& vertices, int count);
    glm::vec3 getRandomColor();
};

struct InstancedRenderComponent {
    std::shared_ptr<InstancedMeshComponent> instancedMesh;
    bool visible;

    InstancedRenderComponent(std::shared_ptr<InstancedMeshComponent> instancedMesh)
        : instancedMesh(instancedMesh), visible(true) {}
};

#endif // GPU_INSTANCING_MESH_HPP