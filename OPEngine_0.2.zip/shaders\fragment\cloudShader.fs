#version 460 core
in vec2 TexCoords;
in vec3 worldPos;
in vec3 viewRay;

out vec4 FragColor;

uniform sampler2D sceneDepthTex;    // Textura de profundidad de la escena
uniform sampler2D sceneColorTex;    // Textura de color de la escena
uniform sampler3D noiseVolume;      // Textura 3D de ruido para las nubes
uniform float time;                 // Tiempo para animación
uniform vec3 cloudColor;            // Color base de las nubes
uniform vec3 lightDir;              // Dirección de la luz
uniform float cloudDensity;         // Densidad de las nubes
uniform float cloudScale;           // Escala de las nubes
uniform float cloudSpeed;           // Velocidad de movimiento
uniform float cloudCoverage;        // Cobertura del cielo
uniform float cloudHeight;          // Altura base de las nubes
uniform float cloudThickness;       // Grosor de la capa de nubes

uniform float nearPlane;
uniform float farPlane;

// Aumentar los pasos para mejor calidad
const int MAX_STEPS = 128;

// Función mejorada para obtener la profundidad de la escena en coordenadas de mundo
float getSceneDepth() {
    float depth = texture(sceneDepthTex, TexCoords).r;

    
    float z = depth * 2.0 - 1.0;
    float near = nearPlane;
    float far = farPlane;
    return (2.0 * near * far) / (far + near - z * (far - near));
}

// Función mejorada para obtener la densidad de la nube
float sampleCloudDensity(vec3 pos) {
    vec3 offset = vec3(time * cloudSpeed * 0.1, time * cloudSpeed * 0.05, 0.0);
    
    // Usar múltiples octavas para un ruido más natural
    float scale1 = cloudScale * 0.001;
    float scale2 = cloudScale * 0.002;
    float scale3 = cloudScale * 0.004;
    
    float noise1 = texture(noiseVolume, pos * scale1 + offset).r;
    float noise2 = texture(noiseVolume, pos * scale2 + offset * 2.0).r * 0.5;
    float noise3 = texture(noiseVolume, pos * scale3 + offset * 3.0).r * 0.25;
    
    // Combinar las octavas
    float noise = noise1 + noise2 + noise3;
    noise = noise / 1.75; // Normalizar
    
    // Calcular el factor de altura con una transición más suave
    float heightFactor = 1.0 - clamp((abs(pos.y - cloudHeight) / (cloudThickness * 0.6)), 0.0, 1.0);
    heightFactor = smoothstep(0.0, 1.0, heightFactor);
    
    // Aplicar coverage con un ajuste más gradual
    float coverageFactor = smoothstep(1.0 - cloudCoverage, 1.0 - cloudCoverage + 0.1, noise);
    
    // Calcular densidad final
    float density = coverageFactor * heightFactor * cloudDensity;
    
    // Añadir variación basada en altura para nubes más interesantes
    float heightVariation = sin(pos.y * 0.02 + noise * 3.0) * 0.1 + 0.9;
    density *= heightVariation;
    
    return density;
}

// Función mejorada para calcular la contribución de luz
vec3 calculateLightContribution(vec3 pos, float density) {
    // Dirección normalizada de la luz
    vec3 lightDirection = normalize(lightDir);
    
    // Usamos múltiples muestras para shadow rays (para mayor precisión)
    float shadowDensity = 0.0;
    const int LIGHT_STEPS = 6;
    float shadowStepSize = 24.0 / float(LIGHT_STEPS);
    
    for (int i = 0; i < LIGHT_STEPS; i++) {
        vec3 shadowPos = pos + lightDirection * (i * shadowStepSize + shadowStepSize * 0.5);
        shadowDensity += sampleCloudDensity(shadowPos) * shadowStepSize * 0.25;
    }
    
    // Cálculo de atenuación basado en la ley de Beer-Lambert con ajustes
    float transmittance = exp(-shadowDensity);
    
    // Ajustes para el color de luz
    vec3 sunColor = vec3(1.0, 0.9, 0.8); // Color ligeramente cálido para el sol
    
    // Silver lining (borde plateado) - Más brillante en el borde de las nubes
    float silverLining = pow(density, 0.5) * 0.5;
    
    // Devolver contribución de luz atenuada con colores ajustados
    return cloudColor * (0.4 + 0.6 * transmittance * sunColor + silverLining);
}

void main() {
    // Obtener el color de la escena original
    vec4 sceneColor = texture(sceneColorTex, TexCoords);
    
    // Obtener la profundidad de la escena
    float sceneDepthDistance = getSceneDepth();
    
    // Calcular la dirección del rayo normalizada
    vec3 ray = normalize(viewRay);
    
    // Punto de inicio del raymarching (posición de la cámara)
    vec3 rayOrigin = worldPos;
    
    // Calcular la intersección con el plano inferior de la capa de nubes
    float cloudBottom = cloudHeight - cloudThickness * 0.5;
    float t1 = (cloudBottom - rayOrigin.y) / ray.y;
    
    // Calcular la intersección con el plano superior de la capa de nubes
    float cloudTop = cloudHeight + cloudThickness * 0.5;
    float t2 = (cloudTop - rayOrigin.y) / ray.y;
    
    // Asegurarse de que t1 sea menor que t2
    if (t1 > t2) {
        float temp = t1;
        t1 = t2;
        t2 = temp;
    }
    
    // Limitar t2 a la profundidad de la escena
    t2 = min(t2, sceneDepthDistance);
    
    // Si el rayo no intersecta con la capa de nubes o está detrás de objetos, usar el color de la escena
    if (t1 > t2 || t2 < 0.0) {
        FragColor = sceneColor;
        return;
    }
    
    // Asegurarse de que t1 sea positivo (frente a la cámara)
    t1 = max(t1, 0.0);
    
    // Calcular el paso para el raymarching - ajustado para ser más preciso
    float stepSize = min(8.0, (t2 - t1) / float(MAX_STEPS));
    int stepsCount = int(ceil((t2 - t1) / stepSize));
    stepsCount = min(stepsCount, MAX_STEPS);
    
    // Acumuladores para el color y la opacidad
    vec4 cloudColor = vec4(0.0);
    float transmittance = 1.0;
    
    // Raymarching a través del volumen de nubes
    for (int i = 0; i < stepsCount; i++) {
        
        float t = t1 + stepSize * float(i);
        vec3 pos = rayOrigin + ray * t;
        
        // Obtener densidad de la nube en esta posición
        float density = sampleCloudDensity(pos);
        
        if (density > 0.0) {
            // Calcular contribución de luz
            vec3 lightContrib = calculateLightContribution(pos, density);
            
            // Calcular absorción usando la ley de Beer-Lambert con ajuste para distancias
            float stepFactor = stepSize * 0.05;
            float absorption = exp(-density * stepFactor);
            
            // Acumular color con ponderación por densidad
            vec3 cloudSample = lightContrib * density * stepFactor;
            
            
            // Fusionar usando blending "over" premultiplicado
            cloudColor.rgb += transmittance * cloudSample;
            
            // Actualizar transmitancia
            transmittance *= absorption;
        }
    }
    
    // Fusionar nubes con la escena original usando un blending adecuado
    vec3 finalColor = sceneColor.rgb * transmittance + cloudColor.rgb;
    
    // Ajuste final de exposición para evitar saturación
    finalColor = finalColor / (finalColor + vec3(1.0));
    finalColor = pow(finalColor, vec3(1.0 / 2.2)); // Corrección de gamma
    
    FragColor = vec4(finalColor, 0.0);
}