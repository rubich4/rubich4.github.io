#ifndef RENDER_HPP
#define RENDER_HPP

#include <GL/glew.h>
#include <memory>
#include "ope/ECSManager.hpp"
#include "ope/Components.hpp"

// Forward declarations
class Shader;
class Camera;
class SkyboxManager;
struct LightComponent;
struct TransformComponent;

class ForwardRenderSystem {
public:

    ForwardRenderSystem(int windowWidth, int windowHeight);
    ~ForwardRenderSystem();

    void forwardRender(EntityManager& em, ComponentManager& componentManager,
        const std::shared_ptr<Shader>& lightShader,
        const std::shared_ptr<Shader>& spotShadowShader,
        const std::shared_ptr<Shader>& pointShadowShader,
        Camera& camera, glm::mat4 lightSpaceMatrix,
        const std::shared_ptr<Shader>& skyboxShader,
        SkyboxManager& skyboxManager);

    glm::mat4 GetLightSpaceMatrix(glm::vec3 lightPos, int lightType, glm::vec3 lightDirection);

    void CreatePointShadowMap(int resolution);
    void CreateSpotLightShadowMap();
    void CreateDirectionalShadowMap();

private:
    void renderEntities(EntityManager& em, ComponentManager& componentManager,
        const std::shared_ptr<Shader>& shader,
        const std::shared_ptr<std::vector<std::tuple<Entity, ColorComponent>>>& colorVector);

    GLuint shadowMapFBO = 0;
    GLuint shadowMap = 0;

    GLuint shadowCubeFBO = 0;
    GLuint shadowCubeMap = 0;

    GLuint spotShadowFBO = 0, spotShadowMap = 0;
    const unsigned int SHADOW_WIDTH = 1024, SHADOW_HEIGHT = 1024;
    GLuint quadVAO = 0, quadVBO = 0;
    int windowWidth, windowHeight;

    // Skybox variables
    bool bSkybox;
    int skyboxSelector;

    float near_plane;
    float far_plane;

    float cutOff;
};

#endif