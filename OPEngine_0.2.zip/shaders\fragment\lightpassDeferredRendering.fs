#version 330 core
out vec4 FragColor;
in vec2 TexCoords;

uniform sampler2D gPosition;
uniform sampler2D gNormal;
uniform sampler2D gAlbedo;
uniform sampler2D ssao;
uniform samplerCube shadowCubeMap;
uniform sampler2D spotShadowMap;
uniform sampler2D dirShadowMap; 
uniform mat4 directionalLightSpaceMatrix; // Matriz para transformar al espacio de luz

uniform vec3 viewPos;
uniform int textureType;
uniform float farPlane;

uniform float bias;

uniform float samples;
uniform float offset;
uniform float shadowStrength;

uniform mat4 lightSpaceMatrix;

float ShadowCalculation(vec3 fragPosWorldSpace, vec3 lightPos) {
    vec3 fragToLight = fragPosWorldSpace - lightPos;
    float currentDepth = length(fragToLight);
    float shadow  = 0.0;
    for(float x = -1.5; x < 1.5; x += 1.5 / (samples * 0.6))
    {
        for(float y = -1.5; y < 1.5; y += 1.5 / (samples * 0.6))
        {
            for(float z = -1.5; z < 1.5; z += 1.5 / (samples * 0.6))
            {
                float closestDepth = texture(shadowCubeMap, fragToLight + vec3(x, y, z)).r; 
                closestDepth *= farPlane;   // undo mapping [0;1]
                if(currentDepth - bias > closestDepth)
                shadow += 1.0;
            }
        }
    }
    shadow /= (samples * samples * samples);

    return shadow;
}

float SpotShadowCalculation(vec3 fragPosWorldSpace, vec3 lightPos) {

    vec4 fragPosLightSpace = lightSpaceMatrix * vec4(fragPosWorldSpace, 1.0);

    // Realizar proyección de perspectiva para obtener coordenadas NDC
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    
    // Transformar a rango [0,1]
    projCoords = projCoords * 0.5 + 0.5;
    
    // Obtener la profundidad más cercana desde el mapa de sombras
    float closestDepth = texture(spotShadowMap, projCoords.xy).r;
    
    // Obtener profundidad actual del fragmento
    float currentDepth = projCoords.z;

    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(spotShadowMap, 0);
    
    for(float x = -3.5; x < 3.5; x += 3.5 / (samples * 0.6)) {
        for(float y = -3.5; y < 3.5; y += 3.5 / (samples * 0.6)) {
            float pcfDepth = texture(spotShadowMap, projCoords.xy + vec2(x, y) * texelSize).r;
            shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;
        }
    }
    
    shadow /= (samples * samples);
    
    // Asegurarse de que no haya sombras fuera del mapa
    if(projCoords.z > 1.0)
        shadow = 0.0;
    
    return shadow;
}

float DirectionalShadowCalculation(vec3 fragPosWorldSpace, vec3 lightDir) {
    // Transformar la posición del fragmento al espacio de luz direccional
    vec4 fragPosLightSpace = directionalLightSpaceMatrix * vec4(fragPosWorldSpace, 1.0);
    
    // Realizar proyección perspectiva para obtener coordenadas NDC
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    
    // Transformar a rango [0,1]
    projCoords = projCoords * 0.5 + 0.5;
    
    // Obtener la profundidad desde el mapa de sombras
    float closestDepth = texture(dirShadowMap, projCoords.xy).r;
    
    // Obtener la profundidad actual
    float currentDepth = projCoords.z;
    
    // PCF (Percentage Closer Filtering) para suavizar las sombras
    float shadow = 0.0;
    vec2 texelSize = 1.0 / textureSize(dirShadowMap, 0);
    
    // Muestreo con PCF para reducir aliasing en bordes de sombras
    for(float x = -2.0; x <= 2.0; x += 1.0) {
        for(float y = -2.0; y <= 2.0; y += 1.0) {
            float pcfDepth = texture(dirShadowMap, projCoords.xy + vec2(x, y) * texelSize).r; 
            shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;        
        }    
    }
    
    shadow /= 25.0; // 5x5 kernel
    
    // Asegurarse de que no hay sombras fuera del frustum
    if(projCoords.z > 1.0)
        shadow = 0.0;
        
    return shadow;
}

struct Light {
    int type_light;
    vec3 position;    // Para luces point y spot
    vec3 direction;   // Para luces direccionales y spot
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float constant;    // Para luces point y spot
    float linear;      // Para luces point y spot
    float quadratic;   // Para luces point y spot
    float cutOff;      // Para luces spot
    float outerCutOff; // Para luces spot
    float strength; 
    float bias;
    float maxDistance;
};

#define MAX_LIGHTS 10
uniform Light lights[MAX_LIGHTS];
uniform int numLights;

void main() {
    if (textureType == 0) {
        // Position
        vec3 FragPos = texture(gPosition, TexCoords).rgb;
        FragColor = vec4(FragPos, 1.0);
    } else if (textureType == 1) {
        // Normals
        vec3 Normal = texture(gNormal, TexCoords).rgb * 2.0 - 1.0;
        FragColor = vec4(Normal, 1.0);
    } else if (textureType == 2) {
        // Albedo
        vec3 Albedo = texture(gAlbedo, TexCoords).rgb;
        FragColor = vec4(Albedo, 1.0);

    } else if (textureType == 3) {  
        float ao = texture(ssao, TexCoords).r;
        FragColor = vec4(vec3(ao), 1.0);

    } else if (textureType == 4) {
        // Lighting
        vec3 FragPos = texture(gPosition, TexCoords).rgb;
        vec3 Normal = texture(gNormal, TexCoords).rgb * 2.0 - 1.0;
        vec3 Albedo = texture(gAlbedo, TexCoords).rgb;

        const float gamma = 2.0;
        Albedo = pow(Albedo, vec3(1.0 / gamma));
        
        float ao = texture(ssao, TexCoords).r;
        
        vec3 lighting;
        vec3 ambient = vec3(0.2 * Albedo * ao);
        vec3 viewDir  = normalize(viewPos - FragPos);
        vec3 totalDiffuse = vec3(0.0);
        vec3 totalSpecular = vec3(0.0);

        for (int i = 0; i < numLights; i++) {
            Light light = lights[i];
            
            vec3 lightDir;
            float attenuation = 1.0;
            float shadow = 0.0;

            float diff = 0.0;
            vec3 diffuse = vec3(0.0);

            vec3 halfwayDir= vec3(0.0);
            float spec = 0.0;
            vec3 specular = vec3(0.0);

            if (light.type_light == 0) { // Point light
                lightDir = normalize(light.position - FragPos);
                float distance = length(light.position - FragPos);
                if (distance > light.maxDistance) {
                    attenuation = 0.0;
                } else {
                    attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
                }
                shadow = ShadowCalculation(FragPos, light.position);
                shadow *= 0.35;

                diff = max(dot(Normal, lightDir), 0.0);
                diffuse = diff * Albedo * light.diffuse * (light.strength * 200);

                // Specular (Blinn-Phong)
                // halfwayDir = normalize(lightDir + viewDir);  
                // spec = pow(max(dot(Normal, halfwayDir), 0.0), 8.0);
                // specular = light.specular * spec;
            
            } else if (light.type_light == 1) { // Directional light

                lightDir = normalize(-light.direction);
                diff = max(dot(Normal, lightDir), 0.0);
                diffuse = diff * Albedo * light.diffuse * (light.strength/2);

                shadow = DirectionalShadowCalculation(FragPos, light.position);
                shadow *= shadowStrength;

                // Specular (Blinn-Phong)
                halfwayDir = normalize(lightDir + viewDir);  
                spec = pow(max(dot(Normal, halfwayDir), 0.0), 32.0);
                specular = light.specular * spec * (light.strength/2);
                
            } else if (light.type_light == 2) { // Spot light
                lightDir = normalize(light.position - FragPos);
                float distance = length(light.position - FragPos);
                attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));

                float theta = dot(lightDir, normalize(-light.direction));
                float epsilon = light.cutOff - light.outerCutOff;
                float intensity = clamp((theta - light.outerCutOff) / epsilon, 0.0, 1.0);
                intensity = clamp(intensity, 0.0, 1.0);
                attenuation = (1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance))) * intensity;

                // Calcular sombras para spotlight usando la textura específica
                shadow = SpotShadowCalculation(FragPos, light.position);
                shadow *= 0.55;

                diff = max(dot(Normal, lightDir), 0.0);
                diffuse = diff * Albedo * light.diffuse * (light.strength * 200);
                
                // Especular para spotlight (también Blinn-Phong)
                halfwayDir = normalize(lightDir + viewDir);  
                spec = pow(max(dot(Normal, halfwayDir), 0.0), 32.0);
                specular = light.specular * spec * light.strength;
            }

            // Aplicar sombras y atenuación
            diffuse *= attenuation * (1.0 - shadow);
            specular *= attenuation * (1.0 - shadow);
            
            totalDiffuse += diffuse;
            totalSpecular += specular;
        }
        
        lighting = (ambient + totalDiffuse + totalSpecular);
        FragColor = vec4(lighting, 1.0);
    }
}